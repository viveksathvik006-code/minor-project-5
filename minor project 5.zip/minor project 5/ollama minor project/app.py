from ollama import chat
response = chat(
    model="gemma3:1b",
    messages=[
        {
            "role": "user",
            "content": "Explain artificial intelligence in simple words."
        }
    ]
)

print(response.message.content)
from ollama import chat
print("Welcome to Local AI Chat")
print("Type 'exit' to stop.\n")
while True:
    question = input("You : ")
    if question.lower() == "exit":
        print("Goodbye!")
        break
    response = chat(
        model="gemma3:1b",
        messages=[
            {
                "role": "user",
                "content": question
            }
        ]
    )
    print("AI :", response["message"]["content"])
    print()