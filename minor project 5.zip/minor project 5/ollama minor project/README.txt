COMMAND:- python -m venv olm
"CREATES VIRTUAL MODEL"

COMMAND:- .\olm\Scripts\Activate.ps1
"RUNS THE VIRTUAL MODEL"

COMMAND:- python -m pip install ollama
"INSTALLS THE OLLAMA IF U HAVE INSTALLED THE OLLAMA"

COMMAND:- python -m pip show ollama 
"SHOW WETHER THE OLLAMA MODEL AND VERSION AND MORE"

COMMAND:- ollama pull gemma3:1b
"GETS THE GEMMA3.1B MODEL FROM THR OLLAMA"

COMMAND:-  python app.py
"RUNS THE PYTHON FILE"

COMMAND:- deactivate
"STOPES THE VIRTUAL MODEL"

TRY OUT PROMPT 
1.who is elon musk
2.how much money  did elon musk gain from his IPO
3.WHAT IS 24/0