 COMMAND:- python -m venv ste
 "CREATS A VIRTUAL MODEL"

 COMMAND :- .\ste\Scripts\Activate.ps1
 " THIS COMMAND IS TO ACTIVATE THE VIRTUAL MODEL"

 COMMAND :- streamlit run tip_calculator.py
 "THIS COMMAND HELPS US TO RUN THE PYTHON FILE IN THE STREAMLIT "
 
 COMMAND :- deactivate
 " STOPS THE VIRTUAL MODEL"
 