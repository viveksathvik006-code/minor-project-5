import streamlit as st
st.title("Simple Tip & Split Calculator")
bill_amount = st.number_input("Enter Bill Amount ($):", min_value=0.0, step=5.0, value=50.0)
tip_percent = st.slider("Tip Percentage (%):", min_value=0, max_value=30, value=10)
num_people = st.number_input("Number of People:", min_value=1, step=1, value=2)

# Calculation button
if st.button("Calculate"):
    tip_amount = bill_amount * (tip_percent / 100)
    total_bill = bill_amount + tip_amount
    per_person = total_bill / num_people

    # Clean metric cards to display results
    st.divider()
    col1, col2 = st.columns(2)
    col1.metric(label="Total Bill (with Tip)", value=f"${total_bill:.2f}")
    col2.metric(label="Each Person Pays", value=f"${per_person:.2f}")